Inspur snmp mib库文件说明

V1.0 2018-12-25
Note：首次增加文档说明
1.Inspur_SNMP_GetSet_Purley_v1.0_20170802.mib.txt
  Note：      snmp get、set mib文件
  Version：   V1.0
  MD5：       513483D7FCC7B51D9AE739EC09EE931A
  ChangeList：无
2.inspurAlert_v2.1_20170811.mib
  Note：      snmp告警mib文件
  Version：   V2.1
  MD5：       615720D837E6DE25F196C3DD7241F939
  ChangeList：无
