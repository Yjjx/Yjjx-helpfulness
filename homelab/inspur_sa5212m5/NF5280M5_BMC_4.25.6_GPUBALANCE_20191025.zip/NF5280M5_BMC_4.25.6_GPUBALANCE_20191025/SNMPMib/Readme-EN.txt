﻿Note：
  1、Document description added for the first time；
  2、mib files need to be imported into third-party tools such as mibbrowser,regardless of the operating system.

V1.5 2019-03-05
1.Inspur_SNMP_GetSet_Purley_v1.5_Digit_20190305.mib
  Note：      snmp get、set mib file
  Version：   V1.5
  MD5：       5495c15387b880e9d7776a47b587bba7
  ChangeList：N/A
2.Inspur_SNMP_GetSet_Purley_v1.4_String_20190302.mib
  Note：      snmp get、set mib file
  Version：   V1.4
  MD5：       5693afbe58b3dae2c140218c4db7cc46
  ChangeList：N/A
3.inspurAlert_v2.2_20190814.mib
  Note：      snmp warn mib file
  Version：   V2.2
  MD5：       9907FD54A306F12FB8F5EA15B459734A
  ChangeList：Add MemVR alert 

V1.4 2019-03-02
1.Inspur_SNMP_GetSet_Purley_v1.4_Digit_20190302.mib
  Note：      snmp get、set mib file
  Version：   V1.4
  MD5：       2d9e2e94acf6b7f5599f91eaeeeb48b7
  ChangeList：N/A
2.Inspur_SNMP_GetSet_Purley_v1.4_String_20190302.mib
  Note：      snmp get、set mib file
  Version：   V1.4
  MD5：       5693afbe58b3dae2c140218c4db7cc46
  ChangeList：N/A
3.inspurAlert_v2.2_20190814.mib
  Note：      snmp warn mib file
  Version：   V2.2
  MD5：       9907FD54A306F12FB8F5EA15B459734A
  ChangeList：Add MemVR alert 

V1.3 2019-02-14
1.Inspur_SNMP_GetSet_Purley_v1.3_20190214.mib
  Note：      snmp get、set mib file
  Version：   V1.3
  MD5：       6c890763f050a84ccec667b4ed54f539
  ChangeList：N/A
2.inspurAlert_v2.2_20190814.mib
  Note：      snmp warn mib file
  Version：   V2.2
  MD5：       9907FD54A306F12FB8F5EA15B459734A
  ChangeList：Add MemVR alert 

V1.2 2019-01-19
1.Inspur_SNMP_GetSet_Purley_v1.2_20190107.mib
  Note：      snmp get、set mib file
  Version：   V1.2
  MD5：       2143AF6885446272C132DC009433D4F1
  ChangeList：N/A
2.inspurAlert_v2.2_20190814.mib
  Note：      snmp warn mib file
  Version：   V2.2
  MD5：       9907FD54A306F12FB8F5EA15B459734A
  ChangeList：Add MemVR alert 
  
V1.1 2019-01-08
1.Inspur_SNMP_GetSet_Purley_v1.2_20190107.mib
  Note：      snmp get、set mib file
  Version：   V1.2
  MD5：       2143AF6885446272C132DC009433D4F1
  ChangeList：N/A
2.inspurAlert_v2.1_20170811.mib
  Note：      snmp warn mib file
  Version：   V2.1
  MD5：       615720D837E6DE25F196C3DD7241F939
  ChangeList：N/A 

V1.0 2018-12-25
1.Inspur_SNMP_GetSet_Purley_v1.0_20170802.mib.txt
  Note：      snmp get、set mib file
  Version：   V1.0
  MD5：       513483D7FCC7B51D9AE739EC09EE931A
  ChangeList：N/A
2.inspurAlert_v2.1_20170811.mib
  Note：      snmp warn mib file
  Version：   V2.1
  MD5：       615720D837E6DE25F196C3DD7241F939
  ChangeList：N/A 
