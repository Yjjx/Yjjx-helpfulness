The driver package files in this folder can be used to install drivers for Intel(R) Ethernet 40GbE Adapters and Connections on the following Operating Systems:
   *  Microsoft Windows Server* 2012 R2 (x64 Edition)
